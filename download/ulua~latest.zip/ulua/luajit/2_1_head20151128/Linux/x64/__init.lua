
require 'strict'
if package.searchpath('host.init.__pkg', package.path) then
  require 'host.init.__pkg'
end