return {
  name = "luajit",
  version = "2.1.head20151128",
  require = { },
  homepage = "http://luajit.org/luajit.html",
  description = "LuaJIT: Just-In-Time Compiler (JIT) for Lua",
  license = "MIT",
}
