
return {
  proxy      = false,
  proxyauth  = false,
  noconfirm  = false,
  silent     = false,
}