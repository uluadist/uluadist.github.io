
return {
  name = "clib_libcurl",
  version = "7.42.1-3",
  require = {
    luajit = "2.0"
  },
  homepage = "http://curl.haxx.se",
  license  = "MIT/X11-derived",
  description = "free and easy-to-use client-side URL transfer library",
}
