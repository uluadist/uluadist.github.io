return {
  description = "serpent : Lua serializer and pretty printer",
  homepage = "https://github.com/pkulchenko/serpent",
  license = "MIT",
  name = "serpent",
  require = {
    luajit = "2.0"
  },
  version = "0.28-103"
}