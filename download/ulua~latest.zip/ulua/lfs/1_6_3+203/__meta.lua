return {
  description = "luafilesystem : File System Library for the Lua Programming Language",
  homepage = "http://keplerproject.github.io/luafilesystem",
  license = "MIT/X11",
  name = "lfs",
  require = {
    luajit = "2.0"
  },
  version = "1.6.3-203"
}